/*
 * Copyright 2018 Jochen Wiedmann
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.github.jochenw.afw.core.log.log4j;

import org.apache.log4j.Logger;

import com.github.jochenw.afw.core.log.AbstractLog;
import com.github.jochenw.afw.core.log.ILog;


/** Implementation of {@link ILog}, which is based on Apache Log4j 1.
 */
public class Log4jLog extends AbstractLog {
    private final Logger logger;

    /**
     * Creates a new instance with the given factory, and logger id.
     * @param pFactory The logger factory, that creates this instance.
     * @param pId The logger id.
     */
    public Log4jLog(Log4jLogFactory pFactory, String pId) {
        super(pFactory, pId);
        logger = Logger.getLogger(pId);
    }

    @Override
    public boolean isTraceEnabled() {
        return logger.isTraceEnabled();
    }

    @Override
    public boolean isDebugEnabled() {
        return logger.isDebugEnabled();
    }

    @Override
    public boolean isInfoEnabled() {
        return logger.isInfoEnabled();
    }

    @Override
    public boolean isWarnEnabled() {
        return logger.isEnabledFor(org.apache.log4j.Level.WARN);
    }

    @Override
    public boolean isErrorEnabled() {
        return logger.isEnabledFor(org.apache.log4j.Level.ERROR);
    }

    @Override
    public boolean isFatalEnabled() {
        return logger.isEnabledFor(org.apache.log4j.Level.FATAL);
    }

    @Override
    public boolean isEnabledFor(Level pLevel) {
        switch (pLevel) {
        case TRACE:
            return logger.isTraceEnabled();
        case DEBUG:
            return logger.isDebugEnabled();
        case INFO:
            return logger.isInfoEnabled();
        case WARN:
            return logger.isEnabledFor(org.apache.log4j.Level.WARN);
        case ERROR:
            return logger.isEnabledFor(org.apache.log4j.Level.ERROR);
        case FATAL:
            return logger.isEnabledFor(org.apache.log4j.Level.FATAL);
        default:
            throw new IllegalStateException("Invalid logging level: " + pLevel);
        }
    }

    @Override
    protected void log(Level pLevel, String pMessage) {
        switch (pLevel) {
        case TRACE:
            logger.trace(pMessage);
            break;
        case DEBUG:
            logger.debug(pMessage);
            break;
        case INFO:
            logger.info(pMessage);
            break;
        case WARN:
            logger.warn(pMessage);
            break;
        case ERROR:
            logger.error(pMessage);
            break;
        case FATAL:
            logger.fatal(pMessage);
            break;
        default:
            throw new IllegalStateException("Invalid logging level: " + pLevel);
        }
    }

    @Override
    protected void log(Level pLevel, String pMessage, Throwable pTh) {
        switch (pLevel) {
        case INFO:
            logger.info(pMessage, pTh);
            break;
        case WARN:
            logger.warn(pMessage, pTh);
            break;
        case ERROR:
            logger.error(pMessage, pTh);
            break;
        case FATAL:
            logger.fatal(pMessage, pTh);
            break;
        default:
            throw new IllegalStateException("Invalid logging level: " + pLevel);
        }
    }

}
