package com.github.jochenw.wxutils.logng.svc;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import com.github.jochenw.afw.core.util.Exceptions;
import com.github.jochenw.afw.core.util.Objects;
import com.softwareag.util.IDataMap;
import com.wm.app.b2b.server.ServiceException;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataUtil;

public abstract class IIsSvc {
	public abstract Object[] run(IDataMap pInput) throws Exception;
	public void run(IData pPipeline) throws ServiceException {
		final IDataMap input = new IDataMap(pPipeline);
		final Object[] output;
		try {
			output = run(input);
		} catch (Exception e) {
			throw Exceptions.show(e, ServiceException.class);
		}
		applyOutput(pPipeline, output);
	}

	protected void applyOutput(IData pPipeline, Object[] pOutput) {
		if (pOutput != null) {
			final IDataCursor crsr = pPipeline.getCursor();
			for(int i = 0;  i < pOutput.length;  i += 2) {
				final Object keyObject = pOutput[i];
				final Object valueObject = pOutput[i+1];
				if (keyObject == null) {
					throw new NullPointerException("Output parameter key " + i + " is null.");
				}
				if (keyObject instanceof String) {
					final String key = (String) keyObject;
					IDataUtil.put(crsr, key, valueObject);
				} else {
					throw new IllegalStateException("Output parameter key " + i + " is not a string, but an instance of " + keyObject.getClass().getName());
				}
			}
			crsr.destroy();
		}
	}

	public static <O extends IIsSvc> void run(Class<O> pServiceType, IData pPipeline) throws ServiceException {
		final Class<O> serviceType = Objects.requireNonNull(pServiceType, "The parameter pServiceType is null.");
		final IData pipeline = Objects.requireNonNull(pPipeline, "The parameter pipeline is null.");
		final Constructor<O> constructor;
		try {
			constructor = serviceType.getConstructor();
		} catch (NoSuchMethodException e) {
			throw new IllegalArgumentException("The service type " + serviceType.getName() + " must have a public default constructor.");
		}
		final O service;
		try {
			service = constructor.newInstance();
		} catch (InstantiationException|IllegalAccessException|IllegalArgumentException e) {
			throw new IllegalStateException("Failed to create an instance of " + serviceType.getName() + ": " + e.getClass().getName() + ", " + e.getMessage(), e);
		} catch (InvocationTargetException e) {
			throw Exceptions.show(e.getCause());
		}
		service.run(pipeline);
	}
}
