package com.github.jochenw.wxutils.logng.svc;

import com.softwareag.util.IDataMap;

public class ParmsLogSvc extends IIsSvc {

	@Override
	public Object[] run(IDataMap pInput) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
