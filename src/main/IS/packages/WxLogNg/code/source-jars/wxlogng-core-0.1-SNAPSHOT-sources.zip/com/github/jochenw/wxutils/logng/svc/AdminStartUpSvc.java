package com.github.jochenw.wxutils.logng.svc;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import java.util.Properties;
import java.util.function.Consumer;

import com.github.jochenw.afw.di.api.Module;
import com.github.jochenw.wxutils.logng.api.IIsFacade;
import com.github.jochenw.wxutils.logng.api.WxLogNg;
import com.github.jochenw.wxutils.logng.api.ILogEvent.Level;
import com.softwareag.util.IDataMap;


public class AdminStartUpSvc extends IIsSvc {
	protected static Properties getWxLogProperties(String pPackageName, IIsFacade pFacade) {
		final String configPropertiesUri = "config/packages/" + pPackageName + "/wxLogNg.properties";
		final String deployedPropertiesUri = "packages/" + pPackageName + "/config/wxLogNg.properties";
		final String factoryPropertiesUri = "packages/" + pPackageName + "/config/wxLogNg-factory.properties";
		final Properties properties = new Properties();
		final Consumer<String> propertyReader = (s) -> {
			final String sXml = s + ".xml";
			if (pFacade.hasFile(sXml)) {
				try (InputStream in = pFacade.read(s)) {
					final Properties pr = new Properties();
					pr.loadFromXML(in);
					properties.putAll(pr);
				} catch (IOException e) {
					throw new UncheckedIOException(e);
				}
			} else if (pFacade.hasFile(s)) {
				try (InputStream in = pFacade.read(s)) {
					final Properties pr = new Properties();
					pr.load(in);
					properties.putAll(pr);
				} catch (IOException e) {
					throw new UncheckedIOException(e);
				}
			}
		};
		propertyReader.accept(factoryPropertiesUri);
		propertyReader.accept(deployedPropertiesUri);
		propertyReader.accept(configPropertiesUri);
		if (properties.isEmpty()) {
			throw new IllegalStateException("Neither of the following properties has been found: "
					+ configPropertiesUri + ", " + deployedPropertiesUri + ", " + configPropertiesUri);
		}
		return properties;
	}

	public static synchronized Module getModule(String pPackageName, IIsFacade pFacade, Module pModule) {
		// May be, test code wants us to use a different module?
		final Module m = WxLogNg.MODULE.extend((b) -> {
			final Properties wxLogProperties = getWxLogProperties(pPackageName, pFacade);
			b.bind(IIsFacade.class).toInstance(pFacade);
			b.bind(Properties.class).toInstance(wxLogProperties);
		});
		if (pModule == null) {
			return m;
		} else {
			return m.extend(pModule);
		}
	}

	public static void init(String pPackageName, IIsFacade pFacade, Module pModule) {
		Objects.requireNonNull(pPackageName, "Package name");
		Objects.requireNonNull(pFacade, "Is Facade");
		Objects.requireNonNull(pModule, "Module");
		WxLogNg.getInstance(getModule(pPackageName, pFacade, pModule));
	}

	@Override
	public Object[] run(IDataMap pInput) throws Exception {
		logWxLogMsg(Level.info, "WxLogNg service is starting at " + DateTimeFormatter.BASIC_ISO_DATE.format(ZonedDateTime.now()));
		return NO_RESULT;
	}
}
